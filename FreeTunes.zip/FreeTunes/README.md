# FreeTunes
Search, stream, and download free Creative Commons music from Jamendo.
Tabs: Home (popular + new), Search (genre tiles + results), Library (Liked Songs, Downloads).
1. Get a free client ID at https://devportal.jamendo.com and set it in `Jamendo.kt`.
2. Open in Android Studio, sync, Run.
