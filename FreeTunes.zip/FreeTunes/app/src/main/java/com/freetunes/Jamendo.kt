package com.freetunes

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Track(
    val id: String,
    val name: String,
    val artist: String,
    val album: String,
    val image: String,
    val streamUrl: String,
    val downloadUrl: String,
    val canDownload: Boolean,
    val license: String,
    val licenseUrl: String,
    val pageUrl: String,
    val localPath: String? = null,
) {
    val attribution: String
        get() = "\"$name\" by $artist, $license. Source: Jamendo ($pageUrl)"

    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("artist", artist); put("album", album)
        put("image", image); put("stream", streamUrl); put("download", downloadUrl)
        put("can", canDownload); put("license", license); put("licenseUrl", licenseUrl)
        put("page", pageUrl); put("local", localPath ?: "")
    }

    companion object {
        fun fromJson(o: JSONObject) = Track(
            o.getString("id"), o.getString("name"), o.getString("artist"), o.optString("album"),
            o.optString("image"), o.optString("stream"), o.optString("download"),
            o.optBoolean("can"), o.optString("license"), o.optString("licenseUrl"),
            o.optString("page"), o.optString("local").ifBlank { null },
        )
    }
}

object Jamendo {
    // Free key: https://devportal.jamendo.com
    const val CLIENT_ID = "YOUR_CLIENT_ID"

    private fun licenseLabel(url: String): String {
        if (url.isBlank()) return "License: see track page"
        if (url.contains("publicdomain") || url.contains("/zero/")) return "CC0"
        val m = Regex("licenses/([a-z\\-]+)/([0-9.]+)").find(url) ?: return "Creative Commons"
        return "CC " + m.groupValues[1].uppercase() + " " + m.groupValues[2]
    }

    suspend fun fetch(
        query: String = "", tag: String = "", order: String = "popularity_week", limit: Int = 40,
    ): List<Track> = withContext(Dispatchers.IO) {
        fun enc(x: String) = URLEncoder.encode(x.trim(), "UTF-8")
        val filter = when {
            query.isNotBlank() -> "&search=${enc(query)}"
            tag.isNotBlank() -> "&tags=${enc(tag)}&order=$order"
            else -> "&order=$order"
        }
        val url = "https://api.jamendo.com/v3.0/tracks/?client_id=$CLIENT_ID" +
            "&format=json&limit=$limit&audioformat=mp32&imagesize=300$filter"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        try {
            val results = JSONObject(conn.inputStream.bufferedReader().readText()).getJSONArray("results")
            List(results.length()) { i ->
                val o = results.getJSONObject(i)
                val ccUrl = o.optString("license_ccurl")
                Track(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    artist = o.getString("artist_name"),
                    album = o.optString("album_name"),
                    image = o.optString("image"),
                    streamUrl = o.getString("audio"),
                    downloadUrl = o.optString("audiodownload"),
                    canDownload = o.optBoolean("audiodownload_allowed", false),
                    license = licenseLabel(ccUrl),
                    licenseUrl = ccUrl,
                    pageUrl = o.optString("shareurl"),
                )
            }
        } finally {
            conn.disconnect()
        }
    }
}

object Library {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Track> {
        val a = JSONArray(prefs(ctx).getString("tracks", "[]"))
        return List(a.length()) { Track.fromJson(a.getJSONObject(it)) }
            .filter { t -> t.localPath?.let { File(it).exists() } == true }
    }

    private fun save(ctx: Context, list: List<Track>) {
        val a = JSONArray(); list.forEach { a.put(it.toJson()) }
        prefs(ctx).edit().putString("tracks", a.toString()).apply()
    }

    fun likes(ctx: Context): List<Track> {
        val a = JSONArray(prefs(ctx).getString("likes", "[]"))
        return List(a.length()) { Track.fromJson(a.getJSONObject(it)) }
    }

    fun toggleLike(ctx: Context, t: Track) {
        val cur = likes(ctx)
        val next = if (cur.any { it.id == t.id }) cur.filter { it.id != t.id } else listOf(t) + cur
        val a = JSONArray(); next.forEach { a.put(it.toJson()) }
        prefs(ctx).edit().putString("likes", a.toString()).apply()
    }

    suspend fun download(ctx: Context, t: Track): Track = withContext(Dispatchers.IO) {
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        val file = File(dir, "${t.id}.mp3")
        val conn = URL(t.downloadUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        try {
            conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
        val saved = t.copy(localPath = file.absolutePath)
        save(ctx, load(ctx).filter { it.id != t.id } + saved)
        saved
    }

    fun delete(ctx: Context, t: Track) {
        t.localPath?.let { File(it).delete() }
        save(ctx, load(ctx).filter { it.id != t.id })
    }
}
