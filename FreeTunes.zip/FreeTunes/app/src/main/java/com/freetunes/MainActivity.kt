package com.freetunes

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val Purple = Color(0xFF8B6CFF)
private val DarkScheme = darkColorScheme(
    primary = Purple, background = Color(0xFF121212), surface = Color(0xFF1E1E1E),
    surfaceVariant = Color(0xFF2A2A2A), onBackground = Color(0xFFF2F2F7), onSurface = Color(0xFFF2F2F7),
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFF5B3FE0), background = Color(0xFFF7F6FB), surface = Color.White,
    surfaceVariant = Color(0xFFE9E7F5),
)

private data class Cat(val name: String, val tag: String, val color: Color)
private val Cats = listOf(
    Cat("Rock", "rock", Color(0xFFC0392B)), Cat("Electronic", "electronic", Color(0xFF2E5BBA)),
    Cat("Pop", "pop", Color(0xFFB03A8C)), Cat("Jazz", "jazz", Color(0xFF8C5A1E)),
    Cat("Hip hop", "hiphop", Color(0xFF3D7A52)), Cat("Classical", "classical", Color(0xFF5B4A9E)),
    Cat("Ambient", "ambient", Color(0xFF1E6F7A)), Cat("Folk", "folk", Color(0xFF7A5A3A)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun Art(url: String, modifier: Modifier, radius: Int = 10) {
    Box(modifier.clip(RoundedCornerShape(radius.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        if (url.isNotBlank()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

private fun toItem(t: Track): MediaItem {
    val uri = t.localPath?.takeIf { File(it).exists() }?.let { Uri.fromFile(File(it)) } ?: Uri.parse(t.streamUrl)
    val meta = MediaMetadata.Builder().setTitle(t.name).setArtist(t.artist).setAlbumTitle(t.album)
        .apply { if (t.image.isNotBlank()) setArtworkUri(Uri.parse(t.image)) }.build()
    return MediaItem.Builder().setMediaId(t.id).setUri(uri).setMediaMetadata(meta).build()
}

private fun fmt(ms: Long): String { val s = (ms / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun TrackRow(
    t: Track, active: Boolean, saved: Boolean, busy: Boolean, showDelete: Boolean,
    onPlay: () -> Unit, onInfo: () -> Unit, onSave: () -> Unit, onDelete: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(if (active) Purple.copy(alpha = 0.14f) else Color.Transparent)
            .clickable { onPlay() }.padding(8.dp),
    ) {
        Art(t.image, Modifier.size(64.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (active) Purple else MaterialTheme.colorScheme.onSurface)
            Text(listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" · "),
                maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            Text(t.license, fontSize = 11.sp, color = Purple)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onInfo, contentPadding = PaddingValues(end = 12.dp)) { Text("Info") }
                when {
                    showDelete -> TextButton(onClick = onDelete) { Text("Delete") }
                    saved -> Text("Saved", style = MaterialTheme.typography.bodySmall)
                    t.canDownload -> TextButton(onClick = onSave, enabled = !busy) { Text(if (busy) "Saving…" else "Save") }
                    else -> Text("Stream only", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }
    var tagName by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Track>()) }
    var popular by remember { mutableStateOf(listOf<Track>()) }
    var newest by remember { mutableStateOf(listOf<Track>()) }
    var libView by remember { mutableStateOf("main") }
    var downloads by remember { mutableStateOf(Library.load(ctx)) }
    var likes by remember { mutableStateOf(Library.likes(ctx)) }
    val busy = remember { mutableStateListOf<String>() }
    val seen = remember { mutableStateMapOf<String, Track>() }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<Track?>(null) }
    var showPlayer by remember { mutableStateOf(false) }

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playing by remember { mutableStateOf(false) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var scrubbing by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({ try { controller = f.get() } catch (_: Exception) {} }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    DisposableEffect(controller) {
        val c = controller
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) { currentId = item?.mediaId }
        }
        if (c != null) { c.addListener(l); playing = c.isPlaying; currentId = c.currentMediaItem?.mediaId }
        onDispose { c?.removeListener(l) }
    }
    LaunchedEffect(playing, currentId) {
        while (playing) {
            if (!scrubbing) position = controller?.currentPosition ?: 0L
            duration = (controller?.duration ?: 1L).coerceAtLeast(1L)
            delay(500)
        }
    }

    fun runSearch() {
        if (query.isBlank() && tag.isBlank()) { results = emptyList(); return }
        scope.launch {
            loading = true; error = null
            try { results = Jamendo.fetch(query = query, tag = tag); results.forEach { seen[it.id] = it } }
            catch (e: Exception) { error = e.message ?: "Network error" }
            loading = false
        }
    }
    LaunchedEffect(Unit) {
        try {
            popular = Jamendo.fetch(order = "popularity_week", limit = 15)
            newest = Jamendo.fetch(order = "releasedate_desc", limit = 15)
            (popular + newest).forEach { seen[it.id] = it }
        } catch (e: Exception) { error = e.message ?: "Network error" }
    }
    downloads.forEach { seen[it.id] = it }

    fun playList(list: List<Track>, index: Int) {
        val c = controller ?: return
        val localById = downloads.associateBy { it.id }
        c.setMediaItems(list.map { toItem(localById[it.id] ?: it) }, index, 0L)
        c.prepare(); c.play()
    }
    fun save(t: Track) {
        if (t.id in busy) return
        busy.add(t.id)
        scope.launch {
            try {
                Library.download(ctx, t); downloads = Library.load(ctx)
                Toast.makeText(ctx, "Saved: ${t.name}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(ctx, "Download failed", Toast.LENGTH_SHORT).show() }
            busy.remove(t.id)
        }
    }
    fun like(t: Track) { Library.toggleLike(ctx, t); likes = Library.likes(ctx) }

    val current = currentId?.let { seen[it] }

    @Composable
    fun Rows(list: List<Track>, inDownloads: Boolean = false) {
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            items(list, key = { it.id }) { t ->
                TrackRow(
                    t, t.id == currentId, downloads.any { it.id == t.id }, t.id in busy, inDownloads,
                    onPlay = { playList(list, list.indexOf(t)) }, onInfo = { info = t },
                    onSave = { save(t) },
                    onDelete = { Library.delete(ctx, t); downloads = Library.load(ctx) },
                )
            }
        }
    }

    @Composable
    fun Header(title: String) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
                Text("F", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    fun Carousel(title: String, list: List<Track>) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { t ->
                Column(Modifier.width(150.dp).clickable { playList(list, list.indexOf(t)) }) {
                    Art(t.image, Modifier.size(150.dp), 8)
                    Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Text(t.license, fontSize = 11.sp, color = Purple)
                }
            }
        }
    }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && tab == 2 && libView != "main") { libView = "main" }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    current?.let { t ->
                        Surface(
                            Modifier.padding(horizontal = 8.dp, vertical = 4.dp).fillMaxWidth().clickable { showPlayer = true },
                            shape = RoundedCornerShape(12.dp), color = Color(0xFF3C2A6B),
                        ) {
                            Column {
                                Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Art(t.image, Modifier.size(40.dp), 6)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                        Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color(0xFFD0C8EA))
                                    }
                                    IconButton(onClick = { like(t) }) {
                                        Icon(if (likes.any { it.id == t.id }) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", tint = Color.White)
                                    }
                                    IconButton(onClick = { controller?.let { if (playing) it.pause() else it.play() } }) {
                                        Text(if (playing) "❚❚" else "▶", color = Color.White)
                                    }
                                }
                                LinearProgressIndicator(
                                    progress = { (position.toFloat() / duration).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(2.dp), color = Color.White, trackColor = Color(0x66000000),
                                )
                            }
                        }
                    }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                        NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                        NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text("Search") })
                        NavigationBarItem(tab == 2, { tab = 2; libView = "main" }, { Icon(Icons.Filled.Favorite, null) }, label = { Text("Library") })
                    }
                }
            },
        ) { inner ->
            Column(Modifier.padding(inner).statusBarsPadding().padding(horizontal = 16.dp).fillMaxSize()) {
                if (Jamendo.CLIENT_ID == "YOUR_CLIENT_ID")
                    Text("Set your Jamendo client ID in Jamendo.kt", color = MaterialTheme.colorScheme.error)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

                when (tab) {
                    0 -> Column(Modifier.fillMaxSize().verticalScrollCompat()) {
                        Header("FreeTunes")
                        if (popular.isEmpty() && error == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                        if (popular.isNotEmpty()) Carousel("Popular this week", popular)
                        if (newest.isNotEmpty()) Carousel("New releases", newest)
                        Spacer(Modifier.height(16.dp))
                    }
                    1 -> Column(Modifier.fillMaxSize()) {
                        Header("Search")
                        OutlinedTextField(
                            value = query, onValueChange = { query = it; if (it.isNotBlank()) { tag = ""; tagName = "" } },
                            placeholder = { Text("What do you want to listen to?") },
                            leadingIcon = { Icon(Icons.Filled.Search, null) },
                            singleLine = true, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                        )
                        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                        if (query.isBlank() && tag.isBlank()) {
                            Text("Browse all", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp))
                            LazyVerticalGrid(GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                gridItems(Cats) { c ->
                                    Box(
                                        Modifier.height(88.dp).clip(RoundedCornerShape(8.dp)).background(c.color)
                                            .clickable { tag = c.tag; tagName = c.name; runSearch() }.padding(12.dp),
                                    ) { Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                                }
                            }
                        } else {
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (tag.isNotBlank()) tagName else "Results", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { query = ""; tag = ""; tagName = ""; results = emptyList() }) { Text("Clear") }
                            }
                            if (!loading && results.isEmpty()) Text("No results", modifier = Modifier.padding(top = 12.dp))
                            Rows(results)
                        }
                    }
                    else -> Column(Modifier.fillMaxSize()) {
                        Header(when (libView) { "liked" -> "Liked Songs"; "downloads" -> "Downloads"; else -> "Your Library" })
                        when (libView) {
                            "liked" -> { if (likes.isEmpty()) Text("Tap the heart on a song to add it here."); Rows(likes) }
                            "downloads" -> { if (downloads.isEmpty()) Text("No downloads yet. Tap Save on any track that allows downloads."); Rows(downloads, true) }
                            else -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                LibEntry("Liked Songs", "${likes.size} songs", Icons.Filled.Favorite) { libView = "liked" }
                                LibEntry("Downloads", "${downloads.size} songs, available offline", Icons.Filled.KeyboardArrowDown) { libView = "downloads" }
                            }
                        }
                    }
                }
            }
        }

        if (showPlayer && current != null) {
            val t = current
            Column(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF3C2A6B), Color(0xFF121212))))
                    .statusBarsPadding().navigationBarsPadding().padding(24.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showPlayer = false }) { Icon(Icons.Filled.KeyboardArrowDown, "Close", tint = Color.White) }
                    Text("Now playing", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(onClick = { info = t }) { Text("Info", color = Color.White) }
                }
                Spacer(Modifier.weight(1f))
                Art(t.image, Modifier.fillMaxWidth().aspectRatio(1f), 14)
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFFD0C8EA))
                        Text(t.license, fontSize = 12.sp, color = Color(0xFFB9A8FF))
                    }
                    IconButton(onClick = { like(t) }) {
                        Icon(if (likes.any { it.id == t.id }) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", tint = Color.White)
                    }
                }
                Slider(
                    value = position.toFloat().coerceIn(0f, duration.toFloat()),
                    onValueChange = { scrubbing = true; position = it.toLong() },
                    onValueChangeFinished = { controller?.seekTo(position); scrubbing = false },
                    valueRange = 0f..duration.toFloat(),
                )
                Row(Modifier.fillMaxWidth()) {
                    Text(fmt(position), fontSize = 12.sp, color = Color(0xFFD0C8EA), modifier = Modifier.weight(1f))
                    Text(fmt(duration), fontSize = 12.sp, color = Color(0xFFD0C8EA))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("|◀", color = Color.White, fontSize = 22.sp) }
                    Box(
                        Modifier.size(68.dp).clip(CircleShape).background(Color.White)
                            .clickable { controller?.let { if (playing) it.pause() else it.play() } },
                        contentAlignment = Alignment.Center,
                    ) { Text(if (playing) "❚❚" else "▶", color = Color.Black, fontSize = 22.sp) }
                    TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("▶|", color = Color.White, fontSize = 22.sp) }
                }
                Spacer(Modifier.height(8.dp))
                val saved = downloads.any { it.id == t.id }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    when {
                        saved -> Text("Saved for offline", color = Color(0xFFD0C8EA))
                        t.canDownload -> OutlinedButton(onClick = { save(t) }, enabled = t.id !in busy) { Text(if (t.id in busy) "Saving…" else "Save for offline", color = Color.White) }
                        else -> Text("Stream only (downloads not allowed by the artist)", color = Color(0xFFD0C8EA), fontSize = 12.sp)
                    }
                }
            }
        }
    }

    info?.let { t ->
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text(t.name) },
            text = {
                Column {
                    Text("Artist: ${t.artist}")
                    if (t.album.isNotBlank()) Text("Album: ${t.album}")
                    Text("License: ${t.license}")
                    Spacer(Modifier.height(8.dp))
                    Text("Credit this track as:", fontWeight = FontWeight.SemiBold)
                    Text(t.attribution, style = MaterialTheme.typography.bodySmall)
                    if (t.pageUrl.isNotBlank()) TextButton(onClick = { openUrl(ctx, t.pageUrl) }) { Text("Open track page") }
                    if (t.licenseUrl.isNotBlank()) TextButton(onClick = { openUrl(ctx, t.licenseUrl) }) { Text("View license terms") }
                }
            },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } },
        )
    }
}

@Composable
private fun LibEntry(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Purple), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier =
    this.then(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()))

private fun openUrl(ctx: Context, url: String) {
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
